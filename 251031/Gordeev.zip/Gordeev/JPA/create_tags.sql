-- Insert the tags
INSERT INTO tbl_tag (name) VALUES ('red485');
INSERT INTO tbl_tag (name) VALUES ('green485');
INSERT INTO tbl_tag (name) VALUES ('blue485');

-- Associate tags with news ID 153
INSERT INTO tbl_news_tag (news_id, tag_id)
SELECT 153, id FROM tbl_tag WHERE name = 'red485';

INSERT INTO tbl_news_tag (news_id, tag_id)
SELECT 153, id FROM tbl_tag WHERE name = 'green485';

INSERT INTO tbl_news_tag (news_id, tag_id)
SELECT 153, id FROM tbl_tag WHERE name = 'blue485'; 