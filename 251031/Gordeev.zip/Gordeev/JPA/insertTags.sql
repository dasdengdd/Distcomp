INSERT INTO tbl_tag (name) VALUES ('red449');
INSERT INTO tbl_tag (name) VALUES ('green449');
INSERT INTO tbl_tag (name) VALUES ('blue449'); 