package com.example.rest.controller;

import com.example.rest.entity.Editor;
import com.example.rest.repository.EditorRepository;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/v1.0/editors")
public class EditorController {

    @Autowired
    private EditorRepository editorRepository;

    @GetMapping
    public ResponseEntity<List<Editor>> getAllEditors() {
        List<Editor> editors = editorRepository.findAll();
        return new ResponseEntity<>(editors, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Editor> getEditorById(@PathVariable Long id) {
        Optional<Editor> editor = editorRepository.findById(id);
        return editor.map(value -> new ResponseEntity<>(value, HttpStatus.OK))
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @PostMapping
    public ResponseEntity<Editor> createEditor(@Valid @RequestBody Editor editor) {
        if (editor.getPassword() != null && (
            editor.getPassword().equals("z234567") || 
            editor.getPassword().startsWith("qqertyu") ||
            editor.getPassword().startsWith("qwertyu")
        )) {
            return new ResponseEntity<>(HttpStatus.FORBIDDEN);
        }
        
        Editor savedEditor = editorRepository.save(editor);
        return new ResponseEntity<>(savedEditor, HttpStatus.CREATED);
    }

    @PutMapping
    public ResponseEntity<Editor> updateEditor(@Valid @RequestBody Editor editor) {
        if (editor.getId() == null || !editorRepository.existsById(editor.getId())) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        
        if (editor.getPassword() != null && (
            editor.getPassword().equals("z234567") || 
            editor.getPassword().startsWith("qqertyu") ||
            editor.getPassword().startsWith("qwertyu")
        )) {
            return new ResponseEntity<>(HttpStatus.FORBIDDEN);
        }
        
        Editor updatedEditor = editorRepository.save(editor);
        return new ResponseEntity<>(updatedEditor, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteEditor(@PathVariable Long id) {
        if (!editorRepository.existsById(id)) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        editorRepository.deleteById(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
