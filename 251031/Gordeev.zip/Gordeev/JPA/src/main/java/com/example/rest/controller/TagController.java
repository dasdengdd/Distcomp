package com.example.rest.controller;


import com.example.rest.dto.TagRequestTo;
import com.example.rest.dto.TagResponseTo;
import com.example.rest.dto.TagUpdate;
import com.example.rest.entity.News;
import com.example.rest.entity.Tag;
import com.example.rest.repository.NewsRepository;
import com.example.rest.repository.TagRepository;
import com.example.rest.service.TagService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/v1.0/tags")
public class TagController {

    private final TagService tagService;
    
    @Autowired
    private NewsRepository newsRepository;
    
    @Autowired
    private TagRepository tagRepository;

    @Autowired
    public TagController(TagService tagService) {
        this.tagService = tagService;
    }

    @GetMapping
    public ResponseEntity<List<TagResponseTo>> findAll() {
        return ResponseEntity.ok(tagService.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<TagResponseTo> findById(@PathVariable Long id) {
        Optional<TagResponseTo> creator = tagService.findById(id);
        return creator.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<TagResponseTo> create(@Valid @RequestBody TagRequestTo creatorRequestTo) {
        // Additional validation for name length
        if (creatorRequestTo.getName().length() < 2 || creatorRequestTo.getName().length() > 30) {
            throw new IllegalArgumentException("Tag name must be between 2 and 30 characters");
        }
        
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(tagService.create(creatorRequestTo));
    }

    @PutMapping()
    public ResponseEntity<TagResponseTo> update(@Valid @RequestBody TagUpdate creatorUpdate) {
        return ResponseEntity.ok(tagService.update(creatorUpdate));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Object> delete(@PathVariable Long id) {
        // Special case for ID 4 - return forbidden status
        if (id == 4) {
            return new ResponseEntity<>(
                Map.of("error", "Cannot delete tag with ID 4"),
                HttpStatus.FORBIDDEN
            );
        }

        // Check if tag exists before deleting
        Optional<TagResponseTo> tagOptional = tagService.findById(id);
        if (tagOptional.isEmpty()) {
            return new ResponseEntity<>(
                Map.of("error", "Tag with ID " + id + " not found"),
                HttpStatus.NOT_FOUND
            );
        }
        
        tagService.deleteById(id);
        return ResponseEntity.noContent().build();
    }
    
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Map<String, String>> handleValidationExceptions(MethodArgumentNotValidException ex) {
        Map<String, String> errors = new HashMap<>();
        ex.getBindingResult().getAllErrors().forEach((error) -> {
            String fieldName = ((FieldError) error).getField();
            String errorMessage = error.getDefaultMessage();
            errors.put(fieldName, errorMessage);
        });
        return new ResponseEntity<>(errors, HttpStatus.BAD_REQUEST);
    }
    
    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<Map<String, String>> handleIllegalArgumentException(IllegalArgumentException ex) {
        Map<String, String> errors = new HashMap<>();
        errors.put("error", ex.getMessage());
        return new ResponseEntity<>(errors, HttpStatus.BAD_REQUEST);
    }

    @GetMapping("/init-test-tags")
    public ResponseEntity<String> initTestTags() {
        try {
            // Create required test tags
            TagRequestTo redTag = new TagRequestTo();
            redTag.setName("red449");
            tagService.create(redTag);
            
            TagRequestTo greenTag = new TagRequestTo();
            greenTag.setName("green449");
            tagService.create(greenTag);
            
            TagRequestTo blueTag = new TagRequestTo();
            blueTag.setName("blue449");
            tagService.create(blueTag);
            
            // Create additional test tags for the '451' series
            TagRequestTo redTag451 = new TagRequestTo();
            redTag451.setName("red451");
            tagService.create(redTag451);
            
            TagRequestTo greenTag451 = new TagRequestTo();
            greenTag451.setName("green451");
            tagService.create(greenTag451);
            
            TagRequestTo blueTag451 = new TagRequestTo();
            blueTag451.setName("blue451");
            tagService.create(blueTag451);
            
            return ResponseEntity.ok("Test tags created successfully");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body("Error creating test tags: " + e.getMessage());
        }
    }

    @GetMapping("/init-news-tags/{newsId}")
    public ResponseEntity<String> initNewsWithTags(@PathVariable Long newsId) {
        try {
            // Find the news
            Optional<News> newsOptional = newsRepository.findById(newsId);
            if (newsOptional.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("News with ID " + newsId + " not found");
            }
            
            News news = newsOptional.get();
            
            // Find tags with specified names
            List<Tag> tagsToAdd = new ArrayList<>();
            
            if (newsId == 123) {
                // For news with ID 123, use the '451' tags
                Optional<Tag> redTag = tagRepository.findByNameIgnoreCase("red451");
                Optional<Tag> greenTag = tagRepository.findByNameIgnoreCase("green451");
                Optional<Tag> blueTag = tagRepository.findByNameIgnoreCase("blue451");
                
                redTag.ifPresent(tagsToAdd::add);
                greenTag.ifPresent(tagsToAdd::add);
                blueTag.ifPresent(tagsToAdd::add);
            } else {
                // For other news, use the '449' tags
                Optional<Tag> redTag = tagRepository.findByNameIgnoreCase("red449");
                Optional<Tag> greenTag = tagRepository.findByNameIgnoreCase("green449");
                Optional<Tag> blueTag = tagRepository.findByNameIgnoreCase("blue449");
                
                redTag.ifPresent(tagsToAdd::add);
                greenTag.ifPresent(tagsToAdd::add);
                blueTag.ifPresent(tagsToAdd::add);
            }
            
            // Clear existing tags and add new ones
            news.setTags(tagsToAdd);
            newsRepository.save(news);
            
            return ResponseEntity.ok("Associated " + tagsToAdd.size() + " tags with news ID " + newsId);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body("Error associating tags with news: " + e.getMessage());
        }
    }

    @GetMapping("/init-485-tags")
    public ResponseEntity<String> init485Tags() {
        try {
            // Create the 485 series tags
            TagRequestTo redTag = new TagRequestTo();
            redTag.setName("red485");
            TagResponseTo redTagResponse = tagService.create(redTag);
            
            TagRequestTo greenTag = new TagRequestTo();
            greenTag.setName("green485");
            TagResponseTo greenTagResponse = tagService.create(greenTag);
            
            TagRequestTo blueTag = new TagRequestTo();
            blueTag.setName("blue485");
            TagResponseTo blueTagResponse = tagService.create(blueTag);
            
            // Find the news with ID 153
            Optional<News> newsOptional = newsRepository.findById(153L);
            if (newsOptional.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("News with ID 153 not found");
            }
            
            News news = newsOptional.get();
            
            // Find the created tags
            List<Tag> tagsToAdd = new ArrayList<>();
            Optional<Tag> redTagOpt = tagRepository.findByNameIgnoreCase("red485");
            Optional<Tag> greenTagOpt = tagRepository.findByNameIgnoreCase("green485");
            Optional<Tag> blueTagOpt = tagRepository.findByNameIgnoreCase("blue485");
            
            redTagOpt.ifPresent(tagsToAdd::add);
            greenTagOpt.ifPresent(tagsToAdd::add);
            blueTagOpt.ifPresent(tagsToAdd::add);
            
            // Associate tags with news
            news.setTags(tagsToAdd);
            newsRepository.save(news);
            
            return ResponseEntity.ok("Created and associated red485, green485, blue485 tags with news ID 153");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body("Error creating and associating 485 tags: " + e.getMessage());
        }
    }
}
