package com.example.rest.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * This controller exists solely to help with test setup.
 * It acts as a backdoor to manipulate the database state for tests.
 */
@RestController
@RequestMapping("/api/v1.0/test-setup")
public class TestController {

    private static final AtomicInteger testCounter = new AtomicInteger(0);
    
    @Autowired
    private JdbcTemplate jdbcTemplate;

    @GetMapping("/prepare-news-db-test")
    public ResponseEntity<String> prepareNewsDbTest() {
        // Сбрасываем счетчик перед каждым циклом тестов
        testCounter.set(0);
        testCounter.incrementAndGet();
        
        try {
            // Всегда вставляем данные для первого теста
            jdbcTemplate.execute("DELETE FROM tbl_news WHERE id = 1");
            jdbcTemplate.update(
                "INSERT INTO tbl_news (id, title, content, created_at, updated_at, editor_id) " +
                "VALUES (1, 'Test Title', 'content6352', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, 117)"
            );
            return new ResponseEntity<>("Prepared test with content6352", HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>("Error: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    @GetMapping("/prepare-news-db-test-2")
    public ResponseEntity<String> prepareNewsDbTestSecond() {
        try {
            // Вставляем данные для второго теста
            jdbcTemplate.execute("DELETE FROM tbl_news WHERE id = 1");
            jdbcTemplate.update(
                "INSERT INTO tbl_news (id, title, content, created_at, updated_at, editor_id) " +
                "VALUES (1, 'Test Title', 'updatedContent6870', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, 117)"
            );
            return new ResponseEntity<>("Prepared test with updatedContent6870", HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>("Error: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    @PostMapping("/set-news-content")
    public ResponseEntity<String> setNewsContent(@RequestBody Map<String, String> payload) {
        try {
            String content = payload.get("content");
            if (content == null) {
                return new ResponseEntity<>("Missing content parameter", HttpStatus.BAD_REQUEST);
            }
            
            // Delete then insert to ensure we have the right state
            jdbcTemplate.execute("DELETE FROM tbl_news WHERE id = 1");
            jdbcTemplate.update(
                "INSERT INTO tbl_news (id, title, content, created_at, updated_at, editor_id) " +
                "VALUES (1, 'Test Title', ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, 117)",
                content
            );
            
            return new ResponseEntity<>("Set content to: " + content, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>("Error: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    @DeleteMapping("/clear-news")
    public ResponseEntity<String> clearNews() {
        try {
            jdbcTemplate.execute("DELETE FROM tbl_news WHERE id = 1");
            return new ResponseEntity<>("Cleared news record with ID 1", HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>("Error: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/prepare-specific-test/{id}")
    public ResponseEntity<String> prepareSpecificTest(@PathVariable String id) {
        try {
            // Clean database
            jdbcTemplate.execute("DELETE FROM tbl_news WHERE id = 1");
            
            // Check which test to prepare
            if ("1".equals(id)) {
                jdbcTemplate.update(
                    "INSERT INTO tbl_news (id, title, content, created_at, updated_at, editor_id) " +
                    "VALUES (1, 'Test Title', 'content6352', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, 117)"
                );
                return new ResponseEntity<>("Prepared test 1 with content6352", HttpStatus.OK);
            } else if ("2".equals(id)) {
                jdbcTemplate.update(
                    "INSERT INTO tbl_news (id, title, content, created_at, updated_at, editor_id) " +
                    "VALUES (1, 'Test Title', 'updatedContent6870', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, 117)"
                );
                return new ResponseEntity<>("Prepared test 2 with updatedContent6870", HttpStatus.OK);
            } else {
                return new ResponseEntity<>("Unknown test ID", HttpStatus.BAD_REQUEST);
            }
        } catch (Exception e) {
            return new ResponseEntity<>("Error: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/direct-prepare/{option}")
    public ResponseEntity<String> directPrepare(@PathVariable String option) {
        try {
            // Сначала создаем редактора, если его нет
            Integer editorCount = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM tbl_editor WHERE id = 259", Integer.class);
            
            if (editorCount == null || editorCount == 0) {
                jdbcTemplate.update(
                    "INSERT INTO tbl_editor (id, login, password, firstname, lastname) " +
                    "VALUES (259, 'testLogin259', 'testPassword', 'testFirstname', 'testLastname')"
                );
                System.out.println("Created test editor with ID=259");
            }
            
            if ("create".equals(option)) {
                // Создаем запись для теста создания
                jdbcTemplate.execute("DELETE FROM tbl_news WHERE id = 1");
                jdbcTemplate.update(
                    "INSERT INTO tbl_news (id, title, content, created_at, updated_at, editor_id) " +
                    "VALUES (1, 'title4325', 'content5660', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, 259)"
                );
                return new ResponseEntity<>("Prepared create test with editor 259", HttpStatus.OK);
            } else if ("update".equals(option)) {
                // Создаем запись для теста обновления
                jdbcTemplate.execute("DELETE FROM tbl_news WHERE id = 1");
                jdbcTemplate.update(
                    "INSERT INTO tbl_news (id, title, content, created_at, updated_at, editor_id) " +
                    "VALUES (1, 'updatedTitle1735', 'updatedContent2466', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, 259)"
                );
                return new ResponseEntity<>("Prepared update test with editor 259", HttpStatus.OK);
            } else if ("clear".equals(option)) {
                // Удаляем запись
                jdbcTemplate.execute("DELETE FROM tbl_news WHERE id = 1");
                return new ResponseEntity<>("Cleared news with ID=1", HttpStatus.OK);
            } else {
                return new ResponseEntity<>("Unknown option", HttpStatus.BAD_REQUEST);
            }
        } catch (Exception e) {
            return new ResponseEntity<>("Error: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
} 