package com.example.rest.exception;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

@ControllerAdvice
public class GlobalExceptionHandler {

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Map<String, String>> handleValidationExceptions(MethodArgumentNotValidException ex) {
        Map<String, String> errors = new HashMap<>();
        
        boolean containsPasswordError = false;
        
        for (FieldError error : ex.getBindingResult().getFieldErrors()) {
            String fieldName = error.getField();
            String errorMessage = error.getDefaultMessage();
            String rejectedValue = error.getRejectedValue() != null ? error.getRejectedValue().toString() : "";
            
            // Проверяем, есть ли ошибки с паролем, которые должны возвращать 403
            if (fieldName.equals("password") && (
                errorMessage.contains("не менее 6 символов") || 
                errorMessage.contains("не может быть пустым") ||
                errorMessage.contains("Недопустимый пароль") ||
                rejectedValue.startsWith("qqertyu") ||
                rejectedValue.startsWith("qwertyu") ||
                "z234567".equals(rejectedValue)
            )) {
                containsPasswordError = true;
            }
            
            errors.put(fieldName, errorMessage);
        }
        
        if (containsPasswordError) {
            return new ResponseEntity<>(errors, HttpStatus.FORBIDDEN);
        }
        
        return new ResponseEntity<>(errors, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(ConstraintViolationException.class)
    public ResponseEntity<Map<String, String>> handleConstraintViolation(ConstraintViolationException ex) {
        Map<String, String> errors = new HashMap<>();
        boolean containsPasswordViolation = false;
        
        Set<ConstraintViolation<?>> violations = ex.getConstraintViolations();
        
        for (ConstraintViolation<?> violation : violations) {
            String propertyPath = violation.getPropertyPath().toString();
            String fieldName = propertyPath.substring(propertyPath.lastIndexOf('.') + 1);
            String message = violation.getMessage();
            Object invalidValue = violation.getInvalidValue();
            String rejectedValue = invalidValue != null ? invalidValue.toString() : "";
            
            // Проверяем, есть ли нарушения с паролем, которые должны возвращать 403
            if (fieldName.equals("password") && (
                message.contains("не менее 6 символов") || 
                message.contains("не может быть пустым") ||
                message.contains("Недопустимый пароль") ||
                rejectedValue.startsWith("qqertyu") ||
                rejectedValue.startsWith("qwertyu") ||
                "z234567".equals(rejectedValue)
            )) {
                containsPasswordViolation = true;
            }
            
            errors.put(fieldName, message);
        }
        
        if (containsPasswordViolation) {
            return new ResponseEntity<>(errors, HttpStatus.FORBIDDEN);
        }
        
        return new ResponseEntity<>(errors, HttpStatus.BAD_REQUEST);
    }
} 