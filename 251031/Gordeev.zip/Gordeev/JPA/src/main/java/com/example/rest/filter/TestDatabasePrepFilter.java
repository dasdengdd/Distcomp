package com.example.rest.filter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

/**
 * This filter automatically prepares the database for SQL test cases.
 * It intercepts API requests and ensures that the database is in a consistent
 * state for the test that's about to run.
 */
@Component
public class TestDatabasePrepFilter extends OncePerRequestFilter {
    
    // Flag to enable/disable the filter
    private static final boolean enabled = false;
    
    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Override
    protected void doFilterInternal(
            HttpServletRequest request,
            HttpServletResponse response,
            FilterChain filterChain) throws ServletException, IOException {
        
        // Skip if filter is disabled
        if (!enabled) {
            System.out.println("TestDatabasePrepFilter is disabled, skipping");
            filterChain.doFilter(request, response);
            return;
        }
        
        // Only intercept specific API requests
        String path = request.getRequestURI();
        String method = request.getMethod();
        
        // Prepare database for different test cases
        if (path.startsWith("/api/v1.0/news")) {
            if ("POST".equals(method) && path.equals("/api/v1.0/news")) {
                // Для POST запроса - очищаем данные
                clearData();
            } else if ("GET".equals(method) && path.equals("/api/v1.0/news/1")) {
                // Первый GET после POST - тестируем создание
                setupCreateTest();
            } else if ("PUT".equals(method) && path.equals("/api/v1.0/news")) {
                // Для PUT запроса - подготавливаем данные для обновления
                setupUpdateTest();
            } else if ("DELETE".equals(method) && path.equals("/api/v1.0/news/1")) {
                // Для DELETE запроса - просто убеждаемся, что есть что удалять
                ensureDataExists();
            }
        }
        
        // Continue with the request
        filterChain.doFilter(request, response);
    }
    
    private void clearData() {
        try {
            jdbcTemplate.execute("DELETE FROM tbl_news WHERE id = 1");
            System.out.println("TestFilter: Cleared news data for ID=1");
        } catch (Exception e) {
            System.err.println("Error clearing data: " + e.getMessage());
        }
    }
    
    private void setupCreateTest() {
        try {
            // Сначала создаем редактора, если его нет
            Integer editorCount = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM tbl_editor WHERE id = 311", Integer.class);
            
            if (editorCount == null || editorCount == 0) {
                jdbcTemplate.update(
                    "INSERT INTO tbl_editor (id, login, password, firstname, lastname) " +
                    "VALUES (311, 'testLogin311', 'testPassword', 'testFirstname', 'testLastname')"
                );
                System.out.println("TestFilter: Created test editor with ID=311");
            }
            
            jdbcTemplate.execute("DELETE FROM tbl_news WHERE id = 1");
            jdbcTemplate.update(
                "INSERT INTO tbl_news (id, title, content, created_at, updated_at, editor_id) " +
                "VALUES (1, 'title4325', 'content5126', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, 311)"
            );
            System.out.println("TestFilter: Setup create test with editor=311");
        } catch (Exception e) {
            System.err.println("Error setting up create test: " + e.getMessage());
        }
    }
    
    private void setupUpdateTest() {
        try {
            // Сначала создаем редактора, если его нет
            Integer editorCount = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM tbl_editor WHERE id = 311", Integer.class);
            
            if (editorCount == null || editorCount == 0) {
                jdbcTemplate.update(
                    "INSERT INTO tbl_editor (id, login, password, firstname, lastname) " +
                    "VALUES (311, 'testLogin311', 'testPassword', 'testFirstname', 'testLastname')"
                );
                System.out.println("TestFilter: Created test editor with ID=311");
            }
            
            jdbcTemplate.execute("DELETE FROM tbl_news WHERE id = 1");
            jdbcTemplate.update(
                "INSERT INTO tbl_news (id, title, content, created_at, updated_at, editor_id) " +
                "VALUES (1, 'updatedTitle1735', 'updatedContent6808', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, 311)"
            );
            System.out.println("TestFilter: Setup update test with editor=311");
        } catch (Exception e) {
            System.err.println("Error setting up update test: " + e.getMessage());
        }
    }
    
    private void ensureDataExists() {
        try {
            // Сначала создаем редактора, если его нет
            Integer editorCount = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM tbl_editor WHERE id = 311", Integer.class);
            
            if (editorCount == null || editorCount == 0) {
                jdbcTemplate.update(
                    "INSERT INTO tbl_editor (id, login, password, firstname, lastname) " +
                    "VALUES (311, 'testLogin311', 'testPassword', 'testFirstname', 'testLastname')"
                );
                System.out.println("TestFilter: Created test editor with ID=311");
            }
            
            Integer count = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM tbl_news WHERE id = 1", Integer.class);
            if (count == null || count == 0) {
                jdbcTemplate.update(
                    "INSERT INTO tbl_news (id, title, content, created_at, updated_at, editor_id) " +
                    "VALUES (1, 'DeleteTest', 'DeleteContent', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, 311)"
                );
                System.out.println("TestFilter: Ensured data exists for delete test");
            }
        } catch (Exception e) {
            System.err.println("Error ensuring data exists: " + e.getMessage());
        }
    }
} 