package com.example.rest.mapper;

import com.example.rest.dto.MessageRequestTo;
import com.example.rest.dto.MessageResponseTo;
import com.example.rest.entity.Message;
import com.example.rest.entity.News;
import com.example.rest.repository.NewsRepository;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.LocalDateTime;

@Mapper(componentModel = "spring", imports = {LocalDateTime.class})
public abstract class MessageMapper {
    
    @Autowired
    protected NewsRepository newsRepository;

    @Mapping(target = "id", source = "id")
    @Mapping(target = "content", source = "content")
    @Mapping(target = "news", source = "newsId", qualifiedByName = "newsIdToNews")
    @Mapping(target = "createdAt", expression = "java(LocalDateTime.now())")
    @Mapping(target = "authorName", constant = "Anonymous")
    @Mapping(target = "authorEmail", constant = "anonymous@example.com")
    public abstract Message toEntity(MessageRequestTo dto);

    @Mapping(target = "id", source = "id")
    @Mapping(target = "content", source = "content")
    @Mapping(target = "newsId", source = "news.id")
    public abstract MessageResponseTo toResponse(Message entity);
    
    @Named("newsIdToNews")
    protected News newsIdToNews(Long newsId) {
        if (newsId == null) {
            return null;
        }
        return newsRepository.findById(newsId).orElse(null);
    }
}
