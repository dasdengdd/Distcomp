package com.example.rest.mapper;

import com.example.rest.dto.NewsRequestTo;
import com.example.rest.dto.NewsResponseTo;
import com.example.rest.entity.Editor;
import com.example.rest.entity.News;
import com.example.rest.repository.EditorRepository;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.LocalDateTime;

@Mapper(componentModel = "spring", imports = {LocalDateTime.class})
public abstract class NewsMapper {
    
    @Autowired
    protected EditorRepository editorRepository;

    @Mapping(target = "id", source = "id")
    @Mapping(target = "title", source = "title")
    @Mapping(target = "content", source = "content")
    @Mapping(target = "editor", source = "editorId", qualifiedByName = "editorIdToEditor")
    @Mapping(target = "createdAt", expression = "java(LocalDateTime.now())")
    @Mapping(target = "updatedAt", expression = "java(LocalDateTime.now())")
    public abstract News toEntity(NewsRequestTo dto);

    @Mapping(target = "id", source = "id")
    @Mapping(target = "title", source = "title")
    @Mapping(target = "content", source = "content")
    @Mapping(target = "editorId", source = "editor.id")
    @Mapping(target = "created", source = "createdAt")
    @Mapping(target = "modified", source = "updatedAt")
    public abstract NewsResponseTo toResponse(News entity);
    
    @Named("editorIdToEditor")
    protected Editor editorIdToEditor(Long editorId) {
        if (editorId == null) {
            return null;
        }
        return editorRepository.findById(editorId).orElse(null);
    }
}