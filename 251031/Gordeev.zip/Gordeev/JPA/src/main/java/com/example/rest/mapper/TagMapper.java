package com.example.rest.mapper;

import com.example.rest.dto.TagRequestTo;
import com.example.rest.dto.TagResponseTo;
import com.example.rest.entity.Tag;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public abstract class TagMapper {
    @Mapping(target = "id", ignore = true)
    public abstract Tag toEntity(TagRequestTo tagRequestTo);
    
    public abstract TagResponseTo toResponse(Tag tag);
}
