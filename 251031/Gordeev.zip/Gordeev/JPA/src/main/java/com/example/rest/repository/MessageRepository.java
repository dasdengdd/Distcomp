package com.example.rest.repository;

import com.example.rest.entity.Message;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MessageRepository extends JpaRepository<Message, Long> {
    // Поиск сообщений по ID новости
    List<Message> findByNewsId(Long newsId);
    
    // Поиск сообщений по имени автора
    List<Message> findByAuthorNameContainingIgnoreCase(String authorName);
    
    // Поиск сообщений по email автора
    List<Message> findByAuthorEmailContainingIgnoreCase(String authorEmail);
    
    // Поиск сообщений по содержимому
    List<Message> findByContentContainingIgnoreCase(String content);
}
