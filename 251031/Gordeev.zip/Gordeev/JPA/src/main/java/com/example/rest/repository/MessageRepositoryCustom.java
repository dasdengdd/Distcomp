package com.example.rest.repository;

import com.example.rest.entity.Message;
import java.util.List;
import java.util.Optional;

/**
 * Custom interface for Message repository methods to be implemented by in-memory repository
 */
public interface MessageRepositoryCustom {
    Message save(Message message);
    void deleteById(Long id);
    Optional<Message> findById(Long id);
    List<Message> findAll();
    List<Message> findByNewsId(Long newsId);
    List<Message> findByAuthorNameContainingIgnoreCase(String authorName);
    List<Message> findByAuthorEmailContainingIgnoreCase(String authorEmail);
    List<Message> findByContentContainingIgnoreCase(String content);
    boolean existsById(Long id);
    long count();
} 