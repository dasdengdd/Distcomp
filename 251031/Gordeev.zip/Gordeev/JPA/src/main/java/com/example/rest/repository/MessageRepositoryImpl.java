package com.example.rest.repository;

import com.example.rest.entity.Message;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Repository;

import java.util.*;

@Repository
@Profile("inmemory")
public class MessageRepositoryImpl implements MessageRepositoryCustom {

    private final Map<Long, Message> messages = new HashMap<>();
    private Long nextId = 1L;

    @Override
    public Message save(Message message) {
        if (message.getId() == null) {
            // Create new
            message.setId(nextId++);
        } else if (!messages.containsKey(message.getId())) {
            throw new IllegalArgumentException("Message not found with ID: " + message.getId());
        }
        
        messages.put(message.getId(), message);
        return message;
    }

    @Override
    public void deleteById(Long id) {
        messages.remove(id);
    }

    @Override
    public Optional<Message> findById(Long id) {
        return Optional.ofNullable(messages.get(id));
    }

    @Override
    public List<Message> findAll() {
        return new ArrayList<>(messages.values());
    }
    
    @Override
    public List<Message> findByNewsId(Long newsId) {
        return messages.values().stream()
            .filter(message -> message.getNews() != null && 
                  Objects.equals(message.getNews().getId(), newsId))
            .toList();
    }
    
    @Override
    public List<Message> findByAuthorNameContainingIgnoreCase(String authorName) {
        if (authorName == null) {
            return new ArrayList<>();
        }
        String searchTerm = authorName.toLowerCase();
        return messages.values().stream()
            .filter(message -> message.getAuthorName() != null && 
                  message.getAuthorName().toLowerCase().contains(searchTerm))
            .toList();
    }
    
    @Override
    public List<Message> findByAuthorEmailContainingIgnoreCase(String authorEmail) {
        if (authorEmail == null) {
            return new ArrayList<>();
        }
        String searchTerm = authorEmail.toLowerCase();
        return messages.values().stream()
            .filter(message -> message.getAuthorEmail() != null && 
                  message.getAuthorEmail().toLowerCase().contains(searchTerm))
            .toList();
    }
    
    @Override
    public List<Message> findByContentContainingIgnoreCase(String content) {
        if (content == null) {
            return new ArrayList<>();
        }
        String searchTerm = content.toLowerCase();
        return messages.values().stream()
            .filter(message -> message.getContent() != null && 
                  message.getContent().toLowerCase().contains(searchTerm))
            .toList();
    }
    
    @Override
    public boolean existsById(Long id) {
        return messages.containsKey(id);
    }
    
    @Override
    public long count() {
        return messages.size();
    }
}
