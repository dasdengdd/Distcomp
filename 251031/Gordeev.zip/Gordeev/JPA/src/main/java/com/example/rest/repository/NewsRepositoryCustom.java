package com.example.rest.repository;

import com.example.rest.entity.News;
import java.util.List;
import java.util.Optional;

/**
 * Custom interface for News repository methods to be implemented by in-memory repository
 */
public interface NewsRepositoryCustom {
    News save(News news);
    void deleteById(Long id);
    Optional<News> findById(Long id);
    List<News> findAll();
    List<News> findByTitleContainingIgnoreCase(String title);
    List<News> findByEditorId(Long editorId);
    List<News> findByContentContainingIgnoreCase(String keyword);
    boolean existsById(Long id);
    long count();
} 