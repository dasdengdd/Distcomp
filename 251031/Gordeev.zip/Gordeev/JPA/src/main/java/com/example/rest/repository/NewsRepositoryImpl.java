package com.example.rest.repository;

import com.example.rest.entity.News;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.*;

@Repository
@Profile("inmemory")
public class NewsRepositoryImpl implements NewsRepositoryCustom {

    private final Map<Long, News> newsMap = new HashMap<>();
    private long nextId = 1L;

    @Override
    public News save(News news) {
        if (news.getId() == null) {
            // Create new
            news.setId(nextId++);
            news.setCreatedAt(LocalDateTime.now());
            news.setUpdatedAt(LocalDateTime.now());
        } else if (!newsMap.containsKey(news.getId())) {
            throw new IllegalArgumentException("News not found with ID: " + news.getId());
        } else {
            // Update existing
            news.setUpdatedAt(LocalDateTime.now());
        }
        
        newsMap.put(news.getId(), news);
        return news;
    }

    @Override
    public void deleteById(Long id) {
        newsMap.remove(id);
    }

    @Override
    public List<News> findAll() {
        return new ArrayList<>(newsMap.values());
    }

    @Override
    public Optional<News> findById(Long id) {
        return Optional.ofNullable(newsMap.get(id));
    }
    
    @Override
    public List<News> findByTitleContainingIgnoreCase(String title) {
        if (title == null) {
            return new ArrayList<>();
        }
        String searchTerm = title.toLowerCase();
        return newsMap.values().stream()
            .filter(news -> news.getTitle() != null && 
                  news.getTitle().toLowerCase().contains(searchTerm))
            .toList();
    }
    
    @Override
    public List<News> findByEditorId(Long editorId) {
        return newsMap.values().stream()
            .filter(news -> news.getEditor() != null && 
                  Objects.equals(news.getEditor().getId(), editorId))
            .toList();
    }
    
    @Override
    public List<News> findByContentContainingIgnoreCase(String keyword) {
        if (keyword == null) {
            return new ArrayList<>();
        }
        String searchTerm = keyword.toLowerCase();
        return newsMap.values().stream()
            .filter(news -> news.getContent() != null && 
                  news.getContent().toLowerCase().contains(searchTerm))
            .toList();
    }
    
    @Override
    public boolean existsById(Long id) {
        return newsMap.containsKey(id);
    }
    
    @Override
    public long count() {
        return newsMap.size();
    }
}
