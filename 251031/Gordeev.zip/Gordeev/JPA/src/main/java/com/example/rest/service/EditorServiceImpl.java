package com.example.rest.service;

import com.example.rest.dto.EditorRequestTo;
import com.example.rest.dto.EditorResponseTo;
import com.example.rest.dto.EditorUpdate;
import com.example.rest.entity.Editor;
import com.example.rest.mapper.EditorMapper;
import com.example.rest.repository.EditorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.http.HttpStatus;

import java.util.List;
import java.util.Optional;

@Service
public class EditorServiceImpl implements EditorService {

    private final EditorRepository editorRepository;
    private final EditorMapper editorMapper;

    // Явное добавление конструктора с @Autowired для инициализации зависимостей
    @Autowired
    public EditorServiceImpl(EditorRepository editorRepository, EditorMapper editorMapper) {
        this.editorRepository = editorRepository;
        this.editorMapper = editorMapper;
    }

    @Override
    public EditorResponseTo create(EditorRequestTo editor) {
        Editor entity = editorMapper.toEntity(editor);
        Editor saved = editorRepository.save(entity);  // Сохраняем сущность через JPA
        return editorMapper.toResponse(saved);  // Возвращаем результат маппинга
    }

    @Override
    public EditorResponseTo update(EditorUpdate updatedEditor) {
        Editor editor = editorRepository.findById(updatedEditor.getId())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Editor not found"));

        editor.setLogin(updatedEditor.getLogin());
        editor.setPassword(updatedEditor.getPassword());
        editor.setFirstname(updatedEditor.getFirstname());
        editor.setLastname(updatedEditor.getLastname());

        Editor saved = editorRepository.save(editor);  // Сохраняем изменения в базе
        return editorMapper.toResponse(saved);  // Возвращаем обновленный объект
    }

    @Override
    public void deleteById(Long id) {
        if (!editorRepository.existsById(id)) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Editor not found");
        }
        editorRepository.deleteById(id);  // Удаляем редактора
    }

    @Override
    public List<EditorResponseTo> findAll() {
        return editorRepository.findAll()
                .stream()
                .map(editorMapper::toResponse)
                .toList();  // Возвращаем все объекты через маппер
    }

    @Override
    public Optional<EditorResponseTo> findById(Long id) {
        return editorRepository.findById(id)
                .map(editorMapper::toResponse);  // Маппим сущность в DTO
    }
}
