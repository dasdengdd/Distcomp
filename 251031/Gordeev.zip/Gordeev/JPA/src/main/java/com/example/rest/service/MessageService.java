package com.example.rest.service;

import com.example.rest.dto.MessageRequestTo;
import com.example.rest.dto.MessageResponseTo;

import java.util.List;

public interface MessageService {
    MessageResponseTo create(MessageRequestTo message);
    MessageResponseTo update(MessageResponseTo message);
    void deleteById(Long id);
    MessageResponseTo findById(Long id);
    List<MessageResponseTo> findAll();
    
    // Extended API methods
    MessageResponseTo createMessage(MessageRequestTo messageRequestTo);
    MessageResponseTo updateMessage(Long id, MessageRequestTo messageRequestTo);
    void deleteMessage(Long id);
    MessageResponseTo getMessage(Long id);
    List<MessageResponseTo> getAllMessages();
    List<MessageResponseTo> getMessagesByNewsId(Long newsId);
    List<MessageResponseTo> searchByAuthorName(String authorName);
    List<MessageResponseTo> searchByAuthorEmail(String authorEmail);
    List<MessageResponseTo> searchByContent(String content);
}
