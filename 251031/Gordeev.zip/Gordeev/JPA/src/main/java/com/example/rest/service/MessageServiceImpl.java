package com.example.rest.service;

import com.example.rest.dto.MessageRequestTo;
import com.example.rest.dto.MessageResponseTo;
import com.example.rest.entity.Message;
import com.example.rest.entity.News;
import com.example.rest.mapper.MessageMapper;
import com.example.rest.repository.MessageRepository;
import com.example.rest.repository.NewsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class MessageServiceImpl implements MessageService {

    @Autowired
    private MessageRepository messageRepository;

    @Autowired
    private NewsRepository newsRepository;

    @Autowired
    private MessageMapper messageMapper;

    @Override
    public MessageResponseTo create(MessageRequestTo messageRequestTo) {
        return createMessage(messageRequestTo);
    }

    @Override
    public MessageResponseTo update(MessageResponseTo messageResponseTo) {
        Message message = messageRepository.findById(messageResponseTo.getId())
                .orElseThrow(() -> new RuntimeException("Message not found"));
        
        message.setContent(messageResponseTo.getContent());
        if (messageResponseTo.getNewsId() != null) {
            News news = newsRepository.findById(messageResponseTo.getNewsId())
                    .orElseThrow(() -> new RuntimeException("News not found"));
            message.setNews(news);
        }
        
        Message updatedMessage = messageRepository.save(message);
        return messageMapper.toResponse(updatedMessage);
    }

    @Override
    public void deleteById(Long id) {
        deleteMessage(id);
    }

    @Override
    public MessageResponseTo findById(Long id) {
        return getMessage(id);
    }

    @Override
    public List<MessageResponseTo> findAll() {
        return getAllMessages();
    }

    @Override
    public MessageResponseTo createMessage(MessageRequestTo messageRequestTo) {
        Message message = messageMapper.toEntity(messageRequestTo);
        Message savedMessage = messageRepository.save(message);
        return messageMapper.toResponse(savedMessage);
    }

    @Override
    public MessageResponseTo updateMessage(Long id, MessageRequestTo messageRequestTo) {
        Message message = messageRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Message not found"));

        // Update only the content, keep the original news reference
        message.setContent(messageRequestTo.getContent());
        if (messageRequestTo.getNewsId() != null) {
            News news = newsRepository.findById(messageRequestTo.getNewsId())
                    .orElseThrow(() -> new RuntimeException("News not found"));
            message.setNews(news);
        }
        
        Message updatedMessage = messageRepository.save(message);
        return messageMapper.toResponse(updatedMessage);
    }

    @Override
    public void deleteMessage(Long id) {
        messageRepository.deleteById(id);
    }

    @Override
    public MessageResponseTo getMessage(Long id) {
        Message message = messageRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Message not found"));
        return messageMapper.toResponse(message);
    }

    @Override
    public List<MessageResponseTo> getAllMessages() {
        List<Message> messages = messageRepository.findAll();
        return messages.stream()
                .map(messageMapper::toResponse)
                .collect(Collectors.toList());
    }

    @Override
    public List<MessageResponseTo> getMessagesByNewsId(Long newsId) {
        List<Message> messages = messageRepository.findByNewsId(newsId);
        return messages.stream()
                .map(messageMapper::toResponse)
                .collect(Collectors.toList());
    }

    @Override
    public List<MessageResponseTo> searchByAuthorName(String authorName) {
        List<Message> messages = messageRepository.findByAuthorNameContainingIgnoreCase(authorName);
        return messages.stream()
                .map(messageMapper::toResponse)
                .collect(Collectors.toList());
    }

    @Override
    public List<MessageResponseTo> searchByAuthorEmail(String authorEmail) {
        List<Message> messages = messageRepository.findByAuthorEmailContainingIgnoreCase(authorEmail);
        return messages.stream()
                .map(messageMapper::toResponse)
                .collect(Collectors.toList());
    }

    @Override
    public List<MessageResponseTo> searchByContent(String content) {
        List<Message> messages = messageRepository.findByContentContainingIgnoreCase(content);
        return messages.stream()
                .map(messageMapper::toResponse)
                .collect(Collectors.toList());
    }
}
