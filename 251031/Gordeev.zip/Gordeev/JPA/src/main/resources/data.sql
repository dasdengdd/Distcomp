-- Insert test editor with ID 117
INSERT INTO tbl_editor (id, login, password, firstname, lastname) 
VALUES (117, 'testLogin', 'testPassword', 'testFirstname', 'testLastname');

-- Insert test news with ID 1
INSERT INTO tbl_news (id, title, content, created_at, updated_at, editor_id)
VALUES (1, 'Test Title', 'Test Content', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, 117); 