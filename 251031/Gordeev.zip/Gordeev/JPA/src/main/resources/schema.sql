-- Drop existing tables if needed
DROP TABLE IF EXISTS tbl_news;
DROP TABLE IF EXISTS tbl_editor;

-- Create tables
CREATE TABLE tbl_editor (
    id BIGINT PRIMARY KEY,
    login VARCHAR(64) NOT NULL UNIQUE,
    password VARCHAR(128) NOT NULL,
    firstname VARCHAR(64) NOT NULL,
    lastname VARCHAR(64) NOT NULL
);

CREATE TABLE tbl_news (
    id BIGINT PRIMARY KEY,
    editor_id BIGINT NOT NULL,
    title VARCHAR(64) NOT NULL,
    content TEXT NOT NULL,
    created_at TIMESTAMP NOT NULL,
    updated_at TIMESTAMP NOT NULL,
    CONSTRAINT fk_news_editor FOREIGN KEY (editor_id) REFERENCES tbl_editor(id)
); 