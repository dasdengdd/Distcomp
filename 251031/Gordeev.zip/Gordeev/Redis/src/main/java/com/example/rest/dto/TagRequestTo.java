package com.example.rest.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

import java.io.Serializable;

public class TagRequestTo implements Serializable {
    private static final long serialVersionUID = 1L;
    
    @NotBlank(message = "Tag name cannot be empty")
    @Size(min = 2, max = 30, message = "Tag name must be between 2 and 30 characters")
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
