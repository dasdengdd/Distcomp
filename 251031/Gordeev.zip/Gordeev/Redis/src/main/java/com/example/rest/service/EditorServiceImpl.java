package com.example.rest.service;

import com.example.rest.dto.EditorRequestTo;
import com.example.rest.dto.EditorResponseTo;
import com.example.rest.dto.EditorUpdate;
import com.example.rest.entity.Editor;
import com.example.rest.mapper.EditorMapper;
import com.example.rest.repository.EditorRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.http.HttpStatus;

import java.util.List;
import java.util.Optional;

@Service
@Slf4j
public class EditorServiceImpl implements EditorService {

    private final EditorRepository editorRepository;
    private final EditorMapper editorMapper;
    private final RedisCacheService cacheService;
    
    private static final String CACHE_KEY_EDITOR = "editor:";
    private static final String CACHE_KEY_ALL_EDITORS = "editors:all";

    @Autowired
    public EditorServiceImpl(EditorRepository editorRepository, 
                            EditorMapper editorMapper,
                            RedisCacheService cacheService) {
        this.editorRepository = editorRepository;
        this.editorMapper = editorMapper;
        this.cacheService = cacheService;
    }

    @Override
    public EditorResponseTo create(EditorRequestTo editor) {
        Editor entity = editorMapper.toEntity(editor);
        Editor saved = editorRepository.save(entity);
        EditorResponseTo response = editorMapper.toResponse(saved);
        
        // Cache the new editor
        cacheService.saveToCache(CACHE_KEY_EDITOR + saved.getId(), response);
        // Invalidate the all editors cache since we added a new one
        cacheService.deleteFromCache(CACHE_KEY_ALL_EDITORS);
        
        log.info("Created and cached editor with ID: {}", saved.getId());
        return response;
    }

    @Override
    public EditorResponseTo update(EditorUpdate updatedEditor) {
        Editor editor = editorRepository.findById(updatedEditor.getId())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Editor not found"));

        editor.setLogin(updatedEditor.getLogin());
        editor.setPassword(updatedEditor.getPassword());
        editor.setFirstname(updatedEditor.getFirstname());
        editor.setLastname(updatedEditor.getLastname());

        Editor saved = editorRepository.save(editor);
        EditorResponseTo response = editorMapper.toResponse(saved);
        
        // Update the cache
        cacheService.saveToCache(CACHE_KEY_EDITOR + saved.getId(), response);
        // Invalidate the all editors cache
        cacheService.deleteFromCache(CACHE_KEY_ALL_EDITORS);
        
        log.info("Updated and cached editor with ID: {}", saved.getId());
        return response;
    }

    @Override
    public void deleteById(Long id) {
        if (!editorRepository.existsById(id)) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Editor not found");
        }
        editorRepository.deleteById(id);
        
        // Remove from cache
        cacheService.deleteFromCache(CACHE_KEY_EDITOR + id);
        // Invalidate the all editors cache
        cacheService.deleteFromCache(CACHE_KEY_ALL_EDITORS);
        
        log.info("Deleted editor with ID: {} and removed from cache", id);
    }

    @Override
    public List<EditorResponseTo> findAll() {
        // Try to get from cache first
        List<EditorResponseTo> cachedEditors = cacheService.getListFromCache(
                CACHE_KEY_ALL_EDITORS, EditorResponseTo.class);
        
        if (!cachedEditors.isEmpty()) {
            log.info("Returning {} editors from cache", cachedEditors.size());
            return cachedEditors;
        }
        
        // If not in cache, get from database
        List<EditorResponseTo> editors = editorRepository.findAll()
                .stream()
                .map(editorMapper::toResponse)
                .toList();
        
        // Cache the result
        cacheService.saveListToCache(CACHE_KEY_ALL_EDITORS, editors);
        log.info("Cached {} editors with key: {}", editors.size(), CACHE_KEY_ALL_EDITORS);
        
        return editors;
    }

    @Override
    public Optional<EditorResponseTo> findById(Long id) {
        // Try to get from cache first
        Optional<EditorResponseTo> cachedEditor = cacheService.getFromCache(
                CACHE_KEY_EDITOR + id, EditorResponseTo.class);
        
        if (cachedEditor.isPresent()) {
            log.info("Returning editor with ID: {} from cache", id);
            return cachedEditor;
        }
        
        // If not in cache, get from database
        Optional<EditorResponseTo> editor = editorRepository.findById(id)
                .map(editorMapper::toResponse);
        
        // Cache the result if found
        editor.ifPresent(e -> {
            cacheService.saveToCache(CACHE_KEY_EDITOR + id, e);
            log.info("Cached editor with ID: {}", id);
        });
        
        return editor;
    }
}
