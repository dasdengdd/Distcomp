package com.example.rest.service;

import com.example.rest.dto.NewsRequestTo;
import com.example.rest.dto.NewsResponseTo;
import com.example.rest.dto.NewsUpdate;
import com.example.rest.entity.News;
import com.example.rest.mapper.NewsMapper;
import com.example.rest.repository.NewsRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@Slf4j
public class NewsServiceImpl implements NewsService {

    private final NewsRepository newsRepository;
    private final NewsMapper newsMapper;
    private final RedisCacheService cacheService;
    
    private static final String CACHE_KEY_NEWS = "news:";
    private static final String CACHE_KEY_ALL_NEWS = "news:all";
    private static final String CACHE_KEY_NEWS_BY_EDITOR = "news:editor:";
    
    @Autowired
    public NewsServiceImpl(NewsRepository newsRepository, 
                          NewsMapper newsMapper,
                          RedisCacheService cacheService) {
        this.newsRepository = newsRepository;
        this.newsMapper = newsMapper;
        this.cacheService = cacheService;
    }
    
    @Override
    public NewsResponseTo create(NewsRequestTo newsRequestTo) {
        News news = newsMapper.toEntity(newsRequestTo);
        News saved = newsRepository.save(news);
        NewsResponseTo response = newsMapper.toResponse(saved);
        
        // Cache the new news item
        cacheService.saveToCache(CACHE_KEY_NEWS + saved.getId(), response);
        // Invalidate related cache keys
        cacheService.deleteFromCache(CACHE_KEY_ALL_NEWS);
        if (saved.getEditor() != null) {
            cacheService.deleteFromCache(CACHE_KEY_NEWS_BY_EDITOR + saved.getEditor().getId());
        }
        
        log.info("Created and cached news with ID: {}", saved.getId());
        return response;
    }

    @Override
    public NewsResponseTo update(NewsUpdate updatedNews) {
        News existing = newsRepository.findById(updatedNews.getId())
                .orElseThrow(() -> new RuntimeException("News not found with id " + updatedNews.getId()));

        if (updatedNews.getTitle() != null) {
            existing.setTitle(updatedNews.getTitle());
        }
        if (updatedNews.getContent() != null) {
            existing.setContent(updatedNews.getContent());
        }

        News updated = newsRepository.save(existing);
        NewsResponseTo response = newsMapper.toResponse(updated);
        
        // Update the cache
        cacheService.saveToCache(CACHE_KEY_NEWS + updated.getId(), response);
        // Invalidate related cache keys
        cacheService.deleteFromCache(CACHE_KEY_ALL_NEWS);
        if (updated.getEditor() != null) {
            cacheService.deleteFromCache(CACHE_KEY_NEWS_BY_EDITOR + updated.getEditor().getId());
        }
        
        log.info("Updated and cached news with ID: {}", updated.getId());
        return response;
    }

    @Override
    public void deleteById(Long id) {
        // Get news before deleting to invalidate related caches
        Optional<News> news = newsRepository.findById(id);
        
        newsRepository.deleteById(id);
        
        // Remove from cache
        cacheService.deleteFromCache(CACHE_KEY_NEWS + id);
        // Invalidate related cache keys
        cacheService.deleteFromCache(CACHE_KEY_ALL_NEWS);
        news.ifPresent(n -> {
            if (n.getEditor() != null) {
                cacheService.deleteFromCache(CACHE_KEY_NEWS_BY_EDITOR + n.getEditor().getId());
            }
        });
        
        log.info("Deleted news with ID: {} and removed from cache", id);
    }

    @Override
    public List<NewsResponseTo> findAll() {
        // Try to get from cache first
        List<NewsResponseTo> cachedNews = cacheService.getListFromCache(
                CACHE_KEY_ALL_NEWS, NewsResponseTo.class);
        
        if (!cachedNews.isEmpty()) {
            log.info("Returning {} news items from cache", cachedNews.size());
            return cachedNews;
        }
        
        // If not in cache, get from database
        List<NewsResponseTo> news = newsRepository.findAll()
                .stream()
                .map(newsMapper::toResponse)
                .toList();
        
        // Cache the result
        cacheService.saveListToCache(CACHE_KEY_ALL_NEWS, news);
        log.info("Cached {} news items with key: {}", news.size(), CACHE_KEY_ALL_NEWS);
        
        return news;
    }

    @Override
    public Optional<NewsResponseTo> findById(Long id) {
        // Try to get from cache first
        Optional<NewsResponseTo> cachedNews = cacheService.getFromCache(
                CACHE_KEY_NEWS + id, NewsResponseTo.class);
        
        if (cachedNews.isPresent()) {
            log.info("Returning news with ID: {} from cache", id);
            return cachedNews;
        }
        
        // If not in cache, get from database
        Optional<NewsResponseTo> news = newsRepository.findById(id)
                .map(newsMapper::toResponse);
        
        // Cache the result if found
        news.ifPresent(n -> {
            cacheService.saveToCache(CACHE_KEY_NEWS + id, n);
            log.info("Cached news with ID: {}", id);
        });
        
        return news;
    }
}
