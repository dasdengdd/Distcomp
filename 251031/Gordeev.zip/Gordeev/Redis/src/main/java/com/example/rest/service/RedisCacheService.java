package com.example.rest.service;

import java.util.List;
import java.util.Optional;

public interface RedisCacheService {
    <T> Optional<T> getFromCache(String key, Class<T> clazz);
    <T> void saveToCache(String key, T value);
    <T> List<T> getListFromCache(String key, Class<T> clazz);
    <T> void saveListToCache(String key, List<T> value);
    void deleteFromCache(String key);
    void clearCache();
} 