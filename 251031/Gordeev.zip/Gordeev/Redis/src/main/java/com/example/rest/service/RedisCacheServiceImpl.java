package com.example.rest.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.RedisConnectionFailureException;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.TimeUnit;

@Service
@RequiredArgsConstructor
@Slf4j
public class RedisCacheServiceImpl implements RedisCacheService {

    private final RedisTemplate<String, Object> redisTemplate;
    private final ObjectMapper objectMapper;
    private static final long CACHE_TTL = 10; // Time to live in minutes

    /**
     * Check if Redis is available
     * @return true if Redis is available, false otherwise
     */
    private boolean isRedisAvailable() {
        try {
            return Boolean.TRUE.equals(redisTemplate.getConnectionFactory().getConnection().ping() != null);
        } catch (Exception e) {
            log.warn("Redis is not available: {}", e.getMessage());
            return false;
        }
    }

    @Override
    public <T> Optional<T> getFromCache(String key, Class<T> clazz) {
        if (!isRedisAvailable()) {
            log.warn("Redis is not available, skipping cache retrieval for key: {}", key);
            return Optional.empty();
        }
        
        try {
            Object cachedValue = redisTemplate.opsForValue().get(key);
            if (cachedValue == null) {
                return Optional.empty();
            }
            
            try {
                if (cachedValue instanceof String) {
                    return Optional.of(objectMapper.readValue((String) cachedValue, clazz));
                } else {
                    return Optional.of(objectMapper.convertValue(cachedValue, clazz));
                }
            } catch (Exception e) {
                log.error("Error deserializing cached value for key {}: {}", key, e.getMessage());
                return Optional.empty();
            }
        } catch (RedisConnectionFailureException e) {
            log.error("Redis connection failure while retrieving key {}: {}", key, e.getMessage());
            return Optional.empty();
        } catch (Exception e) {
            log.error("Unexpected error while retrieving from cache for key {}: {}", key, e.getMessage());
            return Optional.empty();
        }
    }

    @Override
    public <T> void saveToCache(String key, T value) {
        if (!isRedisAvailable()) {
            log.warn("Redis is not available, skipping cache save for key: {}", key);
            return;
        }
        
        try {
            redisTemplate.opsForValue().set(key, value);
            redisTemplate.expire(key, CACHE_TTL, TimeUnit.MINUTES);
            log.debug("Saved to cache with key: {}", key);
        } catch (RedisConnectionFailureException e) {
            log.error("Redis connection failure while saving key {}: {}", key, e.getMessage());
        } catch (Exception e) {
            log.error("Error saving to cache for key {}: {}", key, e.getMessage());
        }
    }

    @Override
    public <T> List<T> getListFromCache(String key, Class<T> clazz) {
        if (!isRedisAvailable()) {
            log.warn("Redis is not available, skipping cache retrieval for list with key: {}", key);
            return new ArrayList<>();
        }
        
        try {
            Object cachedValue = redisTemplate.opsForValue().get(key);
            if (cachedValue == null) {
                return new ArrayList<>();
            }
            
            try {
                if (cachedValue instanceof String) {
                    return objectMapper.readValue((String) cachedValue, 
                            objectMapper.getTypeFactory().constructCollectionType(List.class, clazz));
                } else if (cachedValue instanceof List) {
                    List<?> list = (List<?>) cachedValue;
                    List<T> result = new ArrayList<>();
                    for (Object item : list) {
                        result.add(objectMapper.convertValue(item, clazz));
                    }
                    return result;
                }
                return new ArrayList<>();
            } catch (Exception e) {
                log.error("Error deserializing cached list for key {}: {}", key, e.getMessage());
                return new ArrayList<>();
            }
        } catch (RedisConnectionFailureException e) {
            log.error("Redis connection failure while retrieving list for key {}: {}", key, e.getMessage());
            return new ArrayList<>();
        } catch (Exception e) {
            log.error("Unexpected error while retrieving list from cache for key {}: {}", key, e.getMessage());
            return new ArrayList<>();
        }
    }

    @Override
    public <T> void saveListToCache(String key, List<T> value) {
        if (!isRedisAvailable()) {
            log.warn("Redis is not available, skipping cache save for list with key: {}", key);
            return;
        }
        
        try {
            redisTemplate.opsForValue().set(key, value);
            redisTemplate.expire(key, CACHE_TTL, TimeUnit.MINUTES);
            log.debug("Saved list to cache with key: {}", key);
        } catch (RedisConnectionFailureException e) {
            log.error("Redis connection failure while saving list for key {}: {}", key, e.getMessage());
        } catch (Exception e) {
            log.error("Error saving list to cache for key {}: {}", key, e.getMessage());
        }
    }

    @Override
    public void deleteFromCache(String key) {
        if (!isRedisAvailable()) {
            log.warn("Redis is not available, skipping cache deletion for key: {}", key);
            return;
        }
        
        try {
            redisTemplate.delete(key);
            log.debug("Deleted from cache with key: {}", key);
        } catch (RedisConnectionFailureException e) {
            log.error("Redis connection failure while deleting key {}: {}", key, e.getMessage());
        } catch (Exception e) {
            log.error("Error deleting from cache for key {}: {}", key, e.getMessage());
        }
    }

    @Override
    public void clearCache() {
        if (!isRedisAvailable()) {
            log.warn("Redis is not available, skipping cache clear operation");
            return;
        }
        
        try {
            // Get all keys matching our pattern - we can adjust this based on key naming conventions
            redisTemplate.keys("*").forEach(this::deleteFromCache);
            log.info("Cache cleared");
        } catch (RedisConnectionFailureException e) {
            log.error("Redis connection failure while clearing cache: {}", e.getMessage());
        } catch (Exception e) {
            log.error("Error clearing cache: {}", e.getMessage());
        }
    }
} 