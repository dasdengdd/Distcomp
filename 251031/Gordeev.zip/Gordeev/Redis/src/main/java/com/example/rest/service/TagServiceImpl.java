package com.example.rest.service;

import com.example.rest.dto.TagRequestTo;
import com.example.rest.dto.TagResponseTo;
import com.example.rest.dto.TagUpdate;
import com.example.rest.entity.Tag;
import com.example.rest.mapper.TagMapper;
import com.example.rest.repository.TagRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@Slf4j
public class TagServiceImpl implements TagService {

    private final TagRepository tagRepository;
    private final TagMapper tagMapper;
    private final RedisCacheService cacheService;
    
    private static final String CACHE_KEY_TAG = "tag:";
    private static final String CACHE_KEY_ALL_TAGS = "tags:all";

    @Autowired
    public TagServiceImpl(TagRepository tagRepository, 
                         TagMapper tagMapper,
                         RedisCacheService cacheService) {
        this.tagRepository = tagRepository;
        this.tagMapper = tagMapper;
        this.cacheService = cacheService;
    }

    @Override
    public TagResponseTo create(TagRequestTo tag) {
        Tag entity = tagMapper.toEntity(tag);
        Tag saved = tagRepository.save(entity);
        TagResponseTo response = tagMapper.toResponse(saved);
        
        // Cache the new tag
        cacheService.saveToCache(CACHE_KEY_TAG + saved.getId(), response);
        // Invalidate all tags cache
        cacheService.deleteFromCache(CACHE_KEY_ALL_TAGS);
        
        log.info("Created and cached tag with ID: {}", saved.getId());
        return response;
    }

    @Override
    public TagResponseTo update(TagUpdate updatedTag) {
        Tag tag = tagRepository.findById(updatedTag.getId())
                .orElseThrow(() -> new IllegalArgumentException("Tag not found"));

        if (updatedTag.getId() != null) {
            tag.setId(updatedTag.getId());
        }
        if (updatedTag.getName() != null) {
            tag.setName(updatedTag.getName());
        }

        Tag saved = tagRepository.save(tag);
        TagResponseTo response = tagMapper.toResponse(saved);
        
        // Update the cache
        cacheService.saveToCache(CACHE_KEY_TAG + saved.getId(), response);
        // Invalidate all tags cache
        cacheService.deleteFromCache(CACHE_KEY_ALL_TAGS);
        
        log.info("Updated and cached tag with ID: {}", saved.getId());
        return response;
    }

    @Override
    public void deleteById(Long id) {
        tagRepository.deleteById(id);
        
        // Remove from cache
        cacheService.deleteFromCache(CACHE_KEY_TAG + id);
        // Invalidate all tags cache
        cacheService.deleteFromCache(CACHE_KEY_ALL_TAGS);
        
        log.info("Deleted tag with ID: {} and removed from cache", id);
    }

    @Override
    public List<TagResponseTo> findAll() {
        // Try to get from cache first
        List<TagResponseTo> cachedTags = cacheService.getListFromCache(
                CACHE_KEY_ALL_TAGS, TagResponseTo.class);
        
        if (!cachedTags.isEmpty()) {
            log.info("Returning {} tags from cache", cachedTags.size());
            return cachedTags;
        }
        
        // If not in cache, get from database
        List<TagResponseTo> tags = tagRepository.findAll()
                .stream()
                .map(tagMapper::toResponse)
                .toList();
        
        // Cache the result
        cacheService.saveListToCache(CACHE_KEY_ALL_TAGS, tags);
        log.info("Cached {} tags with key: {}", tags.size(), CACHE_KEY_ALL_TAGS);
        
        return tags;
    }

    @Override
    public Optional<TagResponseTo> findById(Long id) {
        // Try to get from cache first
        Optional<TagResponseTo> cachedTag = cacheService.getFromCache(
                CACHE_KEY_TAG + id, TagResponseTo.class);
        
        if (cachedTag.isPresent()) {
            log.info("Returning tag with ID: {} from cache", id);
            return cachedTag;
        }
        
        // If not in cache, get from database
        Optional<TagResponseTo> tag = tagRepository.findById(id)
                .map(tagMapper::toResponse);
        
        // Cache the result if found
        tag.ifPresent(t -> {
            cacheService.saveToCache(CACHE_KEY_TAG + id, t);
            log.info("Cached tag with ID: {}", id);
        });
        
        return tag;
    }
}
